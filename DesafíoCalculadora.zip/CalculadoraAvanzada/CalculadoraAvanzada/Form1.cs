﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Clases;


namespace CalculadoraAvanzada
{
    public partial class Form1 : Form
    {
        bool inicio = true;
        float primero;
        float segundo;
        float resultado;
        string operador;
        public Form1()
        {
            InitializeComponent();
        }
        Clases.CalBasica obj5 = new Clases.CalBasica();
        Clases.CalAvanzada obj6 = new Clases.CalAvanzada();
        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btn1_Click(object sender, EventArgs e)
        {
            if(inicio)
            {
                txtPantalla.Text = "";
                txtPantalla.Text = "1";
                inicio = false;

            }
            else
            {
                txtPantalla.Text = txtPantalla.Text + "1";
                inicio = false;
            }
        }

        private void btn2_Click(object sender, EventArgs e)
        {
            if (inicio)
            {
                txtPantalla.Text = "";
                txtPantalla.Text = "2";
                inicio = false;

            }
            else
            {
                txtPantalla.Text = txtPantalla.Text + "2";
                inicio = false;
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (inicio)
            {
                txtPantalla.Text = "";
                txtPantalla.Text = "3";
                inicio = false;

            }
            else
            {
                txtPantalla.Text = txtPantalla.Text + "3";
                inicio = false;
            }
        }

        private void btn4_Click(object sender, EventArgs e)
        {
            if (inicio)
            {
                txtPantalla.Text = "";
                txtPantalla.Text = "4";
                inicio = false;

            }
            else
            {
                txtPantalla.Text = txtPantalla.Text + "4";
                inicio = false;
            }
        }

        private void btn5_Click(object sender, EventArgs e)
        {
            if (inicio)
            {
                txtPantalla.Text = "";
                txtPantalla.Text = "5";
                inicio = false;

            }
            else
            {
                txtPantalla.Text = txtPantalla.Text + "5";
                inicio = false;
            }
        }

        private void btn6_Click(object sender, EventArgs e)
        {
            if (inicio)
            {
                txtPantalla.Text = "";
                txtPantalla.Text = "6";
                inicio = false;

            }
            else
            {
                txtPantalla.Text = txtPantalla.Text + "6";
                inicio = false;
            }
        }

        private void btn7_Click(object sender, EventArgs e)
        {
            if (inicio)
            {
                txtPantalla.Text = "";
                txtPantalla.Text = "7";
                inicio = false;

            }
            else
            {
                txtPantalla.Text = txtPantalla.Text + "7";
                inicio = false;
            }
        }

        private void btn8_Click(object sender, EventArgs e)
        {
            if (inicio)
            {
                txtPantalla.Text = "";
                txtPantalla.Text = "8";
                inicio = false;

            }
            else
            {
                txtPantalla.Text = txtPantalla.Text + "8";
                inicio = false;
            }
        }

        private void btn9_Click(object sender, EventArgs e)
        {
            if (inicio)
            {
                txtPantalla.Text = "";
                txtPantalla.Text = "9";
                inicio = false;

            }
            else
            {
                txtPantalla.Text = txtPantalla.Text + "9";
                inicio = false;
            }
        }

        private void btnMulti_Click(object sender, EventArgs e)
        {
            {
                operador = "+";
                primero = float.Parse(txtPantalla.Text);
                txtPantalla.Text = txtPantalla.Text + txtPantalla.Text + "+";
                txtPantalla.Clear();
            }
        }

        private void btnRes_Click(object sender, EventArgs e)
        {
            operador = "-";
            primero = float.Parse(txtPantalla.Text);
            txtPantalla.Text = txtPantalla.Text + txtPantalla.Text + "−";
            txtPantalla.Clear();
        }

        private void btnx_Click(object sender, EventArgs e)
        {
            operador = "*";
            primero = float.Parse(txtPantalla.Text);
            txtPantalla.Text = txtPantalla.Text + txtPantalla.Text + "×";
            txtPantalla.Clear();
        }

        private void btnDivi_Click(object sender, EventArgs e)
        {
            operador = "/";
            primero = float.Parse(txtPantalla.Text);
            txtPantalla.Text = txtPantalla.Text + txtPantalla.Text + "÷";
            txtPantalla.Clear();
        }

        private void btnRaiz_Click(object sender, EventArgs e)
        {
            primero = float.Parse(txtPantalla.Text);
            resultado = primero;
            txtPantalla.Text = "√" + txtPantalla.Text + txtPantalla.Text;
            txtPantalla.Text = Math.Sqrt(primero).ToString();
        }

        private void btncc_Click(object sender, EventArgs e)
        {
            txtPantalla.Clear();
        }

        private void btnPun_Click(object sender, EventArgs e)
        {
            if (txtPantalla.Text.Contains("."))
            {

            }
            else
            {
                txtPantalla.Text = txtPantalla.Text + ".";
            }
        }

        private void btnIgual_Click(object sender, EventArgs e)
        {
            segundo = float.Parse(txtPantalla.Text);

            double Sum;
            double Rest;
            double Mult;
            double Div;
            double pot;

            switch (operador)
            {
                case "+":
                    Sum = obj5.Suma((primero), (segundo));
                    txtPantalla.Text = txtPantalla.Text + txtPantalla.Text;
                    txtPantalla.Text = Sum.ToString();
                    break;
                case "-":
                    Rest = obj5.Resta((primero), (segundo));
                    txtPantalla.Text = txtPantalla.Text + txtPantalla.Text;
                    txtPantalla.Text = Rest.ToString();
                    break;
                case "*":
                    Mult = obj5.Multiplicacion((primero), (segundo));
                    txtPantalla.Text = txtPantalla.Text + txtPantalla.Text;
                    txtPantalla.Text = Mult.ToString();
                    break;
                   
                case "/":
                    Div = obj5.Division((primero), (segundo));
                    txtPantalla.Text = txtPantalla.Text + txtPantalla.Text;
                    txtPantalla.Text = Div.ToString();
                    break;

                case "√":
                    pot = obj6.Potencia((primero),(segundo));
                    txtPantalla.Text = txtPantalla.Text + txtPantalla.Text;
                    txtPantalla.Text = pot.ToString();
                    break;

            }
        }

        private void btnBorrar_Click(object sender, EventArgs e)
        {
            if (txtPantalla.Text.Length == 1)
                txtPantalla.Text = "0";
            else
                txtPantalla.Text = txtPantalla.Text.Substring(0, txtPantalla.Text.Length - 1);
        }

        private void btn0_Click(object sender, EventArgs e)
        {
            if (inicio)
            {
                txtPantalla.Text = "";
                txtPantalla.Text = "0";
                inicio = false;

            }
            else
            {
                txtPantalla.Text = txtPantalla.Text + "0";
                inicio = false;
            }
        }

        private void btnEleva_Click(object sender, EventArgs e)
        {
            operador = "√";
            primero = float.Parse(txtPantalla.Text);
            txtPantalla.Text = txtPantalla.Text + txtPantalla.Text + "√";
            txtPantalla.Clear();
        }
    }
    }

