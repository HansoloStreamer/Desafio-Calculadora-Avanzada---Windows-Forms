﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Clases
{
    public class CalAvanzada
    {
        public double Potencia(double N1, double N2)
        {
            double pot;
            pot = Math.Pow(N1, N2);
            return pot;
        }
    }
}

